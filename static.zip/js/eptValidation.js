
$(function() {
	$('.toggleprop').change(function(param) {
		console.log('param: ' + param);
		console.log('Toggle: ' + $(this).prop('checked'));
		console.log('Toggle ID VALUE: ' + $(this).data('id'));
		var id = $(this).data('id');
		var value = $('#toggle_id_'+id).data('403')
		console.log(":::::::::::::    "+value);
		if(value == '403'){
			console.log(":::inside::::::::::    "+value);
		}else{
			changeStatus($(this).data('id'), $(this).prop('checked'),param);
		}
	});
});

function submitChanges(obj){
	$('#eptValidationDisplayForm').submit();
}
function resetCheckBoxValues(){
	changeCheckBoxValue($('#ept'));
	changeCheckBoxValue($('#cept'));
	changeCheckBoxValue($('#dataFeed'));
};
function changeStatus(id,toggle,param){
	console.log(id+"::::::::::::::::::::::"+toggle);
	var status = toggle ? 'YES' : 'NO';
	$.ajax({
		url : "eptChangeStatus?id="+id+'&status='+status,
		data : "",
		success: function (data) {
        	$("#successmsg").show();
        },
        error: function (e) {
        	if(e.status == 403 || e.status == 401){
        		$('#toggle_id_'+id).data('403','403');
        		$('#toggle_id_'+id).prop('checked', !toggle).change();
        		$('#toggle_id_'+id).removeData( "403");
        	}
        	$("#errormsg").show();
        }
	});
};
