$(document).ready( function () {
	var $pagination = $('.sync-pagination'),
		totalRecords = 0,
		records = [],
		displayRecords = [],
		recPerPage = $('#pageSelect').val(),
		page = 0,
		totalPages = 0,
		displaypages = 6,
		url = ''
		tableBodyKeys = [];
	function loadPageConfigurations(){
		$.ajax({
			type: "GET",
			url: "json/paginationConfig.json",
			success: function(result) {
				var loadedPage = $("#paginationTable").data('value');
				for(var i in result){
					var tableName =  result[i].tableName;
					if(loadedPage == tableName){
						var tableHeader = result[i].tableHeader;
						tableBodyKeys = result[i].tablebody;
						url = result[i].url;
						writeHeader(tableHeader);
						getPageData(0);
						break;
					}
				}
			}
		});
	};
	loadPageConfigurations();
	function pageSizeChange(){
		$("#searchText").val('');
		recPerPage = $('#pageSelect').val();
		$pagination.twbsPagination('destroy');
		loadPageConfigurations();
	};
	function getPageData(page){
		var defaultURL = url+"?page="+page+"&size="+recPerPage;
		getData(defaultURL, undefined);
	};
	function writeHeader(tableHeader){
		$('#table_header_tr').html('');
		var tableHeaderTr = $('#table_header_tr');
		for(var headerLoop = 0;headerLoop < tableHeader.length; headerLoop++){
			tableHeaderTr.append("<th>" + tableHeader[headerLoop] + "</th>");
		}
	};
	function writeTableBodyForNoData(){
		var tableHeaderLength = $("#table_header_tr").children().length;
		$('#table_body').html('');
		var tr = $('<tr class="danger"/>');
		var mid = Math.floor((0 + tableHeaderLength)/2);
		console.log("mid::::    "+mid);
		for(var tbodyLoop = 0; tbodyLoop < tableHeaderLength; tbodyLoop++){
			if(mid == (tbodyLoop-1)){
				tr.append("<td class='text-center text-danger'>No Data</td>");
			}else{
				tr.append("<td/>");
			}
		}
        $('#table_body').append(tr);
	};
	function getData(url,fromSearch){
		$.ajax({
		      url: url,
		      async: true,
		      dataType: 'json',
		      success: function (data) {
		    	  displaypages = 6;
		          records = data.content;
		          console.log(records);
		          totalRecords = data.totalElements;
		          console.log("totalElements                   "+data.totalElements);
		          totalPages = data.totalPages;
		          displayRecordsIndex = Math.max(page - 1, 0) * recPerPage;
		          endRec = (displayRecordsIndex) + recPerPage;
		          displayRecords = records.slice(displayRecordsIndex, endRec);
		          if((totalPages < displaypages) || (fromSearch && $("#searchText").val() == '')){
		        	  displaypages = (fromSearch && $("#searchText").val() == '') ? displaypages : totalPages;
		        	  if(fromSearch){
		        		  $pagination.twbsPagination('destroy');
		        	  }
		          }
		          if(totalRecords > 0){
		        	  apply_pagination(fromSearch);
		        	  generate_table(records);
		          }else{
					  writeTableBodyForNoData();
				  }
		      }
		});
	};
	function apply_pagination(fromSearch) {
		var defaultOpts = {totalPages: totalPages, visiblePages: displaypages, onPageClick: function (event, page) { getPageData(page-1); }};
		if(fromSearch){
			defaultOpts.initiateStartPageClick = false;
			$pagination.twbsPagination($.extend({}, defaultOpts, {
				startPage: 1,
				totalPages: totalPages
				}));
		}else{
			$pagination.twbsPagination(defaultOpts);
		}
	};
	function generate_table(records) {
		if(displayRecords){
			displayRecords = records;
		}
		console.log("displayRecords::::    "+displayRecords.length);
		var tr;
		$('#table_body').html('');
		for (var i = 0; i < displayRecords.length; i++) {
			tr = $('<tr/>');
			for(var tbodyLoop = 0; tbodyLoop < tableBodyKeys.length; tbodyLoop++){
				var jsonKey = tableBodyKeys[tbodyLoop];
				var displayObj = displayRecords[i];
				var value = displayObj[jsonKey] ? displayObj[jsonKey] : "";
				tr.append("<td>" + value + "</td>");
			}
	        $('#table_body').append(tr);
	    }
	};
	function searchData(){
		var searchStr = $("#searchText").val();
		var defaultURL = url+"?page=0&size="+recPerPage+"&searchVal="+searchStr;
		getData(defaultURL,'fromSearch');
	};
	function getTableDetails(){
		return "";
	};
	$("#searchText").keyup(searchData);
	$("#pageSelect").change(pageSizeChange);
});