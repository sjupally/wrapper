=========

## Spring Batch


### Relevant Articles: 
- [Introduction to Spring Batch](http://www.baeldung.com/introduction-to-spring-batch)
- [Spring Batch using Partitioner](http://www.baeldung.com/spring-batch-partitioner)
- [Spring Batch Tasklets vs Chunks Approach](http://www.baeldung.com/spring-batch-tasklet-chunk)
- [How to Trigger and Stop a Scheduled Spring Batch Job](http://www.baeldung.com/spring-batch-start-stop-job)
