package org.baeldung;

import org.junit.Test;
import org.voter.batch.App;

public class SpringContextIntegrationTest {

	@Test
    public final void testMain() throws Exception {
        App.main(null);
	}
}
