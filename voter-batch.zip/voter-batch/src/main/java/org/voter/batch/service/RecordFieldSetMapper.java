package org.voter.batch.service;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;
import org.voter.batch.model.VoterViewVO;

public class RecordFieldSetMapper implements FieldSetMapper<VoterViewVO> {

	public VoterViewVO mapFieldSet(FieldSet voter) throws BindException {
		System.out.println("Field excuted ");
		VoterViewVO voterViewVO = VoterViewVO.builder()
				// .id(voter.readLong("Voter_Id"))
				.caste(voter.readString("CASTE")).casteGroup(voter.readString("CASTE_GROUP"))
				.electorName(voter.readString("Electors_name")).age(voter.readInt("Age"))
				.gender(voter.readString("Gender")).houseNumber(voter.readString("House_No"))
				.mobileNumber(voter.readString("MOBILE_NUMBER")).relativeName(voter.readString("RELATIVE_NAME"))
				.voterId(voter.readString("Voter_Id"))
				// .stateId(voter.readString(index))
				// .stateName(voter.getState().getName())
				// .districtId(voter.readString(""))
				.districtName(voter.readString("district"))
				// .constituencyId(voter.getConstituency().getId())
				.constituencyName(voter.readString("constituency"))
				// .mandalId(voter.getMandal().getId())
				.mandalName(voter.readString("Mandal"))
				// .villageId(voter.getVillage().getId())
				.villageName(voter.readString("Village_Name"))
				// .pollingStationId(voter.getPollingStation().getId())
				.pollingStationName(voter.readString("Polling_Station_Name"))
				// .pollingStationBoothId(voter.readInt("Polling_Station_num"))
				.pollingStationBoothNo(voter.readString("Polling_Station_num"))
				.pollingStationBoothLocation(voter.readString("Polling_Station_Location")).build();

		return voterViewVO;

	}

}
