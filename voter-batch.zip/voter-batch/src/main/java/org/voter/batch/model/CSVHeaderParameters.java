package org.voter.batch.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class CSVHeaderParameters implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2664540688825280201L;
	
	String Voter_Id; 
	String Electors_name; 
	String RELATIVE_NAME; 
	String Gender; 
	String Age;
	String House_No; 
	String CASTE; 
	String CASTE_GROUP; 
	String MOBILE_NUMBER; 
	String district; 
	String constituency; 
	String Mandal; 
	String Village_Name; 
	String Polling_Station_num; 
	String Polling_Station_Name; 
	String Polling_Station_Location; 
	String Total_Schemes_Availed; 
	String CHANDRANNA_POLICY_NUM; 
	String DRSCH_ID_SCHEME_ID; 
	String BCKAPU_BEN_ID; 
	String HOUSING_APPLICATION_ID; 
	String HRSCH_ID_SCHEME_ID; 
	String IIHL_BEN_ID; 
	String INCENTIVE_CP_ID; 
	String MIDH_SCHEMEID; 
	String NTR_PENSION_ID; 
	String PASUPU_SCHEMEID; 
	String RATION_RCID; 
	String RYTHU_POLNUM; 
	String RUNAMAFI_RCID; 
	String SCCORP_BEN_ID; 
	String IN_SUBSIDY_ID; 
	String YUVANESTHAM_ID; 
	String TOT_SANC_BEN_ID;
	
}