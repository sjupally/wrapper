package org.voter.batch;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Split {
	public static void main(String[] args) throws Exception {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(
					"C:\\Users\\srikanth.jupally\\Desktop\\Rajamohan\\Urvakonda_Chilakurupet_Voters\\source.csv", "r");
			long numSplits = 4; // from user input, extract it from args
			long sourceSize = raf.length();
			long bytesPerSplit = sourceSize / numSplits;
			long remainingBytes = sourceSize % numSplits;

			int maxReadBufferSize = 10 * 1024 * 1024; // 100MB
			System.out.println(maxReadBufferSize);
			for (int destIx = 1; destIx <= numSplits; destIx++) {
				BufferedOutputStream bw = new BufferedOutputStream(new FileOutputStream("C:\\Users\\srikanth.jupally\\git\\voter-batch\\src\\main\\resources\\input\\voter\\split_" + destIx+ ".csv"));
				if (bytesPerSplit > maxReadBufferSize) {
					long numReads = bytesPerSplit / maxReadBufferSize;
					long numRemainingRead = bytesPerSplit % maxReadBufferSize;
					for (int i = 0; i < numReads; i++) {
						readWrite(raf, bw, maxReadBufferSize);
					}
					if (numRemainingRead > 0) {
						readWrite(raf, bw, numRemainingRead);
					}
				} else {
					readWrite(raf, bw, bytesPerSplit);
				}
				bw.close();
			}
			if (remainingBytes > 0) {
				BufferedOutputStream bw = new BufferedOutputStream(new FileOutputStream("C:\\Users\\srikanth.jupally\\git\\voter-batch\\src\\main\\resources\\input\\voter\\split_" + (numSplits + 1) + ".csv"));
				readWrite(raf, bw, remainingBytes);
				bw.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			raf.close();
		}
	}

	static void readWrite(RandomAccessFile raf, BufferedOutputStream bw, long numBytes) throws IOException {
		byte[] buf = new byte[(int) numBytes];
		int val = raf.read(buf);
		if (val != -1) {
			bw.write(buf);
		}
	}
}