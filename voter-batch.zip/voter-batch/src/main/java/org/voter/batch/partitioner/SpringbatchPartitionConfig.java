package org.voter.batch.partitioner;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.voter.batch.model.Transaction;
import org.voter.batch.model.VoterViewVO;
import org.voter.batch.service.CustomItemProcessor;
import org.voter.batch.service.RecordFieldSetMapper;

@Configuration
@EnableBatchProcessing
public class SpringbatchPartitionConfig {

    @Autowired
    ResourcePatternResolver resoursePatternResolver;

    @Autowired
    private JobBuilderFactory jobs;

    @Autowired
    private StepBuilderFactory steps;

    @Bean(name = "partitionerJob")
    public Job partitionerJob() throws UnexpectedInputException, MalformedURLException, ParseException {
        return jobs.get("partitionerJob")
          .start(partitionStep())
          .build();
    }
    
    @Bean
	public ItemProcessor<VoterViewVO, VoterViewVO> itemProcessor() {
		return new CustomItemProcessor();
	}

    @Bean
    public Step partitionStep() throws UnexpectedInputException, MalformedURLException, ParseException {
        return steps.get("partitionStep")
          .partitioner("slaveStep", partitioner())
          .step(slaveStep())
          .taskExecutor(taskExecutor())
          .build();
    }

    @Bean
    public Step slaveStep() throws UnexpectedInputException, MalformedURLException, ParseException {
        return steps.get("slaveStep")
          .<VoterViewVO, VoterViewVO>chunk(1000)
          .reader(itemReader(null))
          .processor(itemProcessor())
          .writer(new VoterWriter())
          .build();
    }

    @Bean
    public CustomMultiResourcePartitioner partitioner() {
        CustomMultiResourcePartitioner partitioner = new CustomMultiResourcePartitioner();
        Resource[] resources;
        try {
            resources = resoursePatternResolver.getResources("file:src/main/resources/input/voter/*.csv");
        } catch (IOException e) {
            throw new RuntimeException("I/O problems when resolving the input file pattern.", e);
        }
        partitioner.setResources(resources);
        return partitioner;
    }

    @Bean
    @StepScope
    public FlatFileItemReader<VoterViewVO> itemReader(@Value("#{stepExecutionContext[fileName]}") String filename) throws UnexpectedInputException, ParseException {
    	System.out.println("File started reading {} "+ filename);
        FlatFileItemReader<VoterViewVO> reader = new FlatFileItemReader<>();
        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
        String[] tokens = {"Voter_Id" , "Electors_name" , "RELATIVE_NAME" , "Gender" , "Age" , "House_No" , "CASTE" , "CASTE_GROUP" , "MOBILE_NUMBER" , 
        		"district" , "constituency" , "Mandal" , "Village_Name" , "Polling_Station_num" , "Polling_Station_Name" , "Polling_Station_Location" , 
        		"Total_Schemes_Availed" , "CHANDRANNA_POLICY_NUM" , "DRSCH_ID_SCHEME_ID" , "BCKAPU_BEN_ID" , "HOUSING_APPLICATION_ID" , "HRSCH_ID_SCHEME_ID" ,
        		"IIHL_BEN_ID" , "INCENTIVE_CP_ID" , "MIDH_SCHEMEID" , "NTR_PENSION_ID" , "PASUPU_SCHEMEID" , "RATION_RCID" , "RYTHU_POLNUM" , "RUNAMAFI_RCID" , 
        		"SCCORP_BEN_ID" , "IN_SUBSIDY_ID" , "YUVANESTHAM_ID" , "TOT_SANC_BEN_ID"};
        tokenizer.setNames(tokens);
        reader.setResource(new ClassPathResource("input/voter/" + filename));
        DefaultLineMapper<VoterViewVO> lineMapper = new DefaultLineMapper<>();
        lineMapper.setLineTokenizer(tokenizer);
        lineMapper.setFieldSetMapper(new RecordFieldSetMapper());
        reader.setLinesToSkip(1);
        reader.setLineMapper(lineMapper);
        return reader;
    }

    /*@Bean(destroyMethod = "")
    @StepScope
    public ItemWriter<VoterViewVO> itemWriter(Marshaller marshaller, @Value("#{stepExecutionContext[opFileName]}") String filename) throws MalformedURLException {
    	System.out.println("File started Writing {} "+ filename);
        ItemWriter<VoterViewVO> itemWriter = new ItemWriter<>();
        itemWriter.setMarshaller(marshaller);
        itemWriter.setRootTagName("voter");
        itemWriter.setResource(new FileSystemResource("src/main/resources/output/" + filename));
        return itemWriter;
    }*/

    @Bean
    public Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setClassesToBeBound(Transaction.class);
        return marshaller;
    }

    @Bean
    public TaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(10);
        taskExecutor.setCorePoolSize(10);
        taskExecutor.setQueueCapacity(10);
        taskExecutor.afterPropertiesSet();
        return taskExecutor;
    }

    private JobRepository getJobRepository() throws Exception {
        JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
        factory.setDataSource(dataSource());
        factory.setTransactionManager(getTransactionManager());
        // JobRepositoryFactoryBean's methods Throws Generic Exception,
        // it would have been better to have a specific one
        factory.afterPropertiesSet();
        return factory.getObject();
    }

    private DataSource dataSource() {
        EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
        return builder.setType(EmbeddedDatabaseType.HSQL)
          .addScript("classpath:org/springframework/batch/core/schema-drop-h2.sql")
          .addScript("classpath:org/springframework/batch/core/schema-h2.sql")
          .build();
    }

    private PlatformTransactionManager getTransactionManager() {
        return new ResourcelessTransactionManager();
    }

    public JobLauncher getJobLauncher() throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        // SimpleJobLauncher's methods Throws Generic Exception,
        // it would have been better to have a specific one
        jobLauncher.setJobRepository(getJobRepository());
        jobLauncher.afterPropertiesSet();
        return jobLauncher;
    }
}
