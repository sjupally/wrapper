package org.voter.batch.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@XmlRootElement(name = "voter")
@ToString
public class VoterViewVO implements Serializable
{
	private static final long serialVersionUID = 1L;
	private Long id;
	private String voterId;
	private String electorName;
	private String relativeName;
	private Integer age;
	private String gender;
	private String mobileNumber;
	private String caste;
	private String casteGroup;
	private String houseNumber;
	private Long stateId;
	private String stateName;
	private Long districtId;
	private String districtName;
	private Long constituencyId;
	private String constituencyName;
	private Long mandalId;
	private String mandalName;
	private Long villageId;
	private String villageName;
	private Long pollingStationId;
	private String pollingStationName;
	private Long pollingStationBoothId;
	private String pollingStationBoothNo;
	private String pollingStationBoothLocation;
	private Integer totalSchemes;
	private Integer availedSchemes;
	//private List<DepartmentVO> departments;
	
}

