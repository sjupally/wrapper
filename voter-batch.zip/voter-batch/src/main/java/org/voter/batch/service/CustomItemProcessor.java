package org.voter.batch.service;

import org.springframework.batch.item.ItemProcessor;
import org.voter.batch.model.VoterViewVO;

public class CustomItemProcessor implements ItemProcessor<VoterViewVO, VoterViewVO> {

	@Override
	public VoterViewVO process(VoterViewVO item) throws Exception {
		//System.out.println("Processing..." + item);
		return item;
	}
}