package org.voter.batch.partitioner;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.voter.batch.model.VoterViewVO;

public class VoterWriter implements ItemWriter<VoterViewVO> {

	@Override
	public void write(List<? extends VoterViewVO> messages) throws Exception {
		System.out.println("Writing the data " + messages);
	}

}
